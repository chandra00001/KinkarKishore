package com.greatlearning.library.SpringBootLibraryDesign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.greatlearning.library.SpringBootLibraryDesign.model.GreatLearning;

@SpringBootApplication
public class SpringBootLibraryDesignApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootLibraryDesignApplication.class, args);
		System.out.println("hello Spring Boot");
		System.out.println("hello dev tools");

	}
	public void run(String... args) throws Exception {
		GreatLearning greatLearning = new GreatLearning();
		greatLearning.setCourseName("test course");
		greatLearning.setCourseType("Informstion tech");
		greatLearning.setInstructorName("Samarth narula");
		System.out.println("course name:"+greatLearning);
	

	}

}
