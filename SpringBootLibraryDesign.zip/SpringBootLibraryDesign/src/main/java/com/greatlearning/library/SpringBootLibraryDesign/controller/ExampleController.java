package com.greatlearning.library.SpringBootLibraryDesign.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.greatlearning.library.SpringBootLibraryDesign.model.GreatLearning;





//@Controller
@RestController
public class ExampleController {

	@GetMapping("/info")
//	@ResponseBody
	public GreatLearning get() {
		GreatLearning greatLearning = new GreatLearning();
		greatLearning.setCourseName("Learn controller inspring boot");
		greatLearning.setCourseType("information tech");
		greatLearning.setInstructorName("samarth narula");
		return greatLearning;

	}

	@PostMapping("customInfo")
	public GreatLearning customInfo(String courseName, String CourseType, String instructorName) {
		GreatLearning greatLearning = new GreatLearning();
		greatLearning.setCourseName(courseName);
		greatLearning.setCourseType(CourseType);
		greatLearning.setInstructorName(instructorName);
		return greatLearning;

	}

}
